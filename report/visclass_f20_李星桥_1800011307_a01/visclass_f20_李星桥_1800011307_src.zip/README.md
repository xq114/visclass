# visclass
PKU visualization homework fall 20

## build instruction

develop (start a server to preview):

using `npm`:
```
npm install
npm run dev
```

using `yarn`:
```
yarn
yarn dev
```

build:

using `npm`:
```
npm install
npm run build
cd build
```

using `yarn`:
```
yarn
yarn build
cd bulid
```